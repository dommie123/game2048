package game;

import game.Frame;

public class MaingGame {
		public static void main(String[] args) {
			Frame game2048 = new Frame();
		}
}
